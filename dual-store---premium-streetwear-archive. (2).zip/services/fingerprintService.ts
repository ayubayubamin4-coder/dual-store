
/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/

export interface DeviceMetadata {
  browser: string;
  platform: string;
  language: string;
  cores: number;
  memory?: number;
  gpu: string;
  screen: string;
  battery: string;
  connection: string;
  timezone: string;
  touchPoints: number;
  cookiesEnabled: boolean;
}

export const getGpuInfo = (): string => {
  const canvas = document.createElement('canvas');
  const gl = canvas.getContext('webgl') || canvas.getContext('experimental-webgl');
  if (!gl) return "Unknown";
  const debugInfo = (gl as WebGLRenderingContext).getExtension('WEBGL_debug_renderer_info');
  return debugInfo ? (gl as WebGLRenderingContext).getParameter(debugInfo.UNMASKED_RENDERER_WEBGL) : "Generic WebGL";
};

export const harvestMetadata = async (): Promise<DeviceMetadata> => {
  const battery: any = (navigator as any).getBattery ? await (navigator as any).getBattery() : null;
  const conn: any = (navigator as any).connection || {};

  return {
    browser: navigator.userAgent,
    platform: (navigator as any).platform || 'Unknown',
    language: navigator.language,
    cores: navigator.hardwareConcurrency || 0,
    memory: (navigator as any).deviceMemory || 0,
    gpu: getGpuInfo(),
    screen: `${window.screen.width}x${window.screen.height} (${window.screen.colorDepth}-bit)`,
    battery: battery ? `${(battery.level * 100).toFixed(0)}% (${battery.charging ? 'Charging' : 'Discharging'})` : 'Blocked/Unavailable',
    connection: `${conn.effectiveType || 'unknown'} (Downlink: ${conn.downlink || '??'} Mbps)`,
    timezone: Intl.DateTimeFormat().resolvedOptions().timeZone,
    touchPoints: navigator.maxTouchPoints || 0,
    cookiesEnabled: navigator.cookieEnabled
  };
};
