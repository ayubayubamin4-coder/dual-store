
/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/

export enum AppState {
  DASHBOARD,
  ARMED,
  CAPTURING,
  REPORT,
}

export interface IntrusionEvent {
  id: string;
  timestamp: number;
  photoBase64: string;
  location?: {
    latitude: number;
    longitude: number;
    accuracy: number;
  };
  deviceInfo: {
    userAgent: string;
    batteryLevel?: number;
    platform: string;
  };
  analysis?: string;
}

export interface AnalysisResponse {
  summary: string;
  threatLevel: 'Low' | 'Medium' | 'High' | 'Critical';
  observations: string[];
}

// Add missing types for Veo video generation models
export enum VeoModel {
  VEO_FAST = 'veo-3.1-fast-generate-preview',
  VEO = 'veo-3.1-generate-preview',
}

// Aspect ratio definitions for video generation
export enum AspectRatio {
  LANDSCAPE = '16:9',
  PORTRAIT = '9:16',
}

// Resolution options for video output
export enum Resolution {
  P720 = '720p',
  P1080 = '1080p',
  P4K = '4K',
}

// Modes for different types of video generation workflows
export enum GenerationMode {
  TEXT_TO_VIDEO = 'Text to Video',
  SCRIPT_TO_VIDEO = 'Script to Video',
  FRAMES_TO_VIDEO = 'Frames to Video',
  REFERENCES_TO_VIDEO = 'References to Video',
  EXTEND_VIDEO = 'Extend Video',
}

// Generic interface for images with both File and base64 representation
export interface ImageFile {
  file: File;
  base64: string;
}

// Generic interface for videos with both File and base64 representation
export interface VideoFile {
  file: File;
  base64: string;
}

// Configuration parameters for the video generation service call
export interface GenerateVideoParams {
  prompt: string;
  model: VeoModel;
  aspectRatio: AspectRatio;
  resolution: Resolution;
  mode: GenerationMode;
  startFrame: ImageFile | null;
  endFrame: ImageFile | null;
  referenceImages: ImageFile[];
  styleImage: ImageFile | null;
  inputVideo: VideoFile | null;
  inputVideoObject: any | null;
  isLooping: boolean;
}
