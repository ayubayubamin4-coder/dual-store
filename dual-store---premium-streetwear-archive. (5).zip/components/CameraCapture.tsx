
/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
import React, { useRef, useState, useEffect } from 'react';
import { CameraIcon, XMarkIcon } from './icons';
import { ImageFile } from '../types';

interface CameraCaptureProps {
  onCapture: (image: ImageFile) => void;
  onClose: () => void;
}

const CameraCapture: React.FC<CameraCaptureProps> = ({ onCapture, onClose }) => {
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [stream, setStream] = useState<MediaStream | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const startCamera = async () => {
      try {
        const mediaStream = await navigator.mediaDevices.getUserMedia({
          video: { facingMode: 'environment', width: { ideal: 1280 }, height: { ideal: 720 } },
          audio: false
        });
        setStream(mediaStream);
        if (videoRef.current) {
          videoRef.current.srcObject = mediaStream;
        }
      } catch (err) {
        console.error('Error accessing camera:', err);
        setError('Could not access camera. Please ensure you have granted permission.');
      }
    };

    startCamera();

    return () => {
      if (stream) {
        stream.getTracks().forEach(track => track.stop());
      }
    };
  }, []);

  const handleCapture = () => {
    if (videoRef.current && canvasRef.current) {
      const video = videoRef.current;
      const canvas = canvasRef.current;
      canvas.width = video.videoWidth;
      canvas.height = video.videoHeight;
      const ctx = canvas.getContext('2d');
      if (ctx) {
        ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
        const dataUrl = canvas.toDataURL('image/jpeg');
        const base64 = dataUrl.split(',')[1];
        
        // Create a File object from the blob
        fetch(dataUrl)
          .then(res => res.blob())
          .then(blob => {
            const file = new File([blob], `capture_${Date.now()}.jpg`, { type: 'image/jpeg' });
            onCapture({ file, base64 });
            onClose();
          });
      }
    }
  };

  return (
    <div className="fixed inset-0 z-[100] bg-black/90 backdrop-blur-md flex items-center justify-center p-4">
      <div className="relative w-full max-w-2xl bg-gray-900 border border-gray-700 rounded-3xl overflow-hidden shadow-2xl">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 z-10 p-2 bg-black/40 hover:bg-black/60 rounded-full text-white transition-colors"
        >
          <XMarkIcon className="w-6 h-6" />
        </button>

        <div className="relative aspect-video bg-black flex items-center justify-center">
          {error ? (
            <div className="text-center p-8">
              <CameraIcon className="w-12 h-12 text-gray-600 mx-auto mb-4" />
              <p className="text-red-400 font-medium">{error}</p>
              <button onClick={onClose} className="mt-4 text-indigo-400 hover:underline">Go back</button>
            </div>
          ) : (
            <>
              <video
                ref={videoRef}
                autoPlay
                playsInline
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 pointer-events-none border-[20px] border-transparent shadow-[inset_0_0_100px_rgba(0,0,0,0.5)]"></div>
            </>
          )}
        </div>

        {!error && (
          <div className="p-6 bg-gray-900 flex justify-center items-center gap-6">
            <button
              onClick={handleCapture}
              className="group relative flex items-center justify-center"
            >
              <div className="absolute inset-0 bg-white/20 rounded-full animate-ping group-active:scale-95 transition-transform"></div>
              <div className="relative w-16 h-16 bg-white rounded-full border-4 border-gray-300 group-hover:bg-gray-100 group-active:scale-90 transition-all shadow-xl flex items-center justify-center">
                 <div className="w-12 h-12 bg-indigo-600 rounded-full flex items-center justify-center">
                    <CameraIcon className="w-6 h-6 text-white" />
                 </div>
              </div>
            </button>
            <p className="text-gray-400 text-sm font-medium">Capture high-res reference</p>
          </div>
        )}
        <canvas ref={canvasRef} className="hidden" />
      </div>
    </div>
  );
};

export default CameraCapture;
