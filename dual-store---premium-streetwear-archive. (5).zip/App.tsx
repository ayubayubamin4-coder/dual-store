
import React, { useState, useEffect, useRef, useMemo } from 'react';
import { 
  ShoppingBag, 
  Sparkles, 
  X, 
  ArrowRight, 
  Instagram, 
  Twitter, 
  Plus, 
  Send, 
  Trash2, 
  CreditCard, 
  CheckCircle2,
  Lock,
  LogOut,
  Mail,
  Zap,
  LayoutGrid,
  ClipboardList,
  Search,
  Filter,
  User,
  Heart,
  MessageSquare,
  Facebook,
  Smartphone,
  MapPin,
  Menu,
  ChevronRight,
  TrendingUp,
  Award,
  Key,
  Phone,
  Ban,
  Wallet,
  Settings,
  Package,
  Clock,
  CheckCircle,
  PlusCircle,
  FileText,
  Upload,
  Archive,
  Eye,
  EyeOff,
  Image as ImageIcon,
  ChevronLeft,
  ShieldCheck,
  AlertCircle,
  Music2,
  Maximize2,
  ZoomIn
} from 'lucide-react';
import { GoogleGenAI } from '@google/genai';

// --- Configuration & Types ---
const ADMIN_EMAILS = ["ayubayubamin4@gmail.com", "merwanjemal22@gmail.com"];
const SOCIAL_HANDLE = "@dual_store2";
const INSTAGRAM_URL = "https://www.instagram.com/dual_store2";
const TIKTOK_URL = "https://www.tiktok.com/@dual_store2";

type Gender = 'MEN' | 'WOMEN' | 'UNISEX';
type View = 'HOME' | 'SHOP' | 'ADMIN' | 'CHECKOUT' | 'SUCCESS' | 'PRODUCT_DETAIL';
type Category = 'T-SHIRTS' | 'HOODIES' | 'JACKETS' | 'PANTS' | 'ACCESSORIES';
type OrderStatus = 'Pending (Unpaid)' | 'Confirmed (Awaiting Payment)' | 'Paid' | 'Shipped' | 'Delivered' | 'Cancelled' | 'Archived';
type ProductStatus = 'Active' | 'Out of Stock' | 'Hidden';

interface Product {
  id: string;
  name: string;
  price: number;
  category: Category;
  gender: Gender;
  image: string; // Thumbnail
  images: string[]; // Full archive of high-res base64
  description: string;
  status: ProductStatus;
  sizes: string[];
}

interface Order {
  id: string;
  customerName: string;
  customerEmail: string;
  address: string;
  phone: string;
  items: Product[];
  subtotal: number;
  discount: number;
  total: number;
  status: OrderStatus;
  paymentMethod: 'Telebirr' | 'CBE';
  timestamp: number;
}

const App: React.FC = () => {
  const [currentView, setCurrentView] = useState<View>('HOME');
  const [products, setProducts] = useState<Product[]>([]);
  const [cart, setCart] = useState<Product[]>([]);
  const [orders, setOrders] = useState<Order[]>([]);
  const [filterGender, setFilterGender] = useState<Gender | 'ALL'>('ALL');
  const [filterCategory, setFilterCategory] = useState<Category | 'ALL'>('ALL');
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [activeImageIdx, setActiveImageIdx] = useState(0);
  const [isLightboxOpen, setIsLightboxOpen] = useState(false);

  // Discount & Payment Settings (Admin Editable)
  const [isDiscountEnabled, setIsDiscountEnabled] = useState(true);
  const [discountPercent, setDiscountPercent] = useState(15);
  const [hasUsedFirstOrderDiscount, setHasUsedFirstOrderDiscount] = useState(false);
  
  const [paymentInfo, setPaymentInfo] = useState({
    telebirr: '0912345678 (Ayub)',
    cbe: '1000123456789 (Merwan)'
  });

  // Admin Security
  const [isAdmin, setIsAdmin] = useState(false);
  const [showAdminLogin, setShowAdminLogin] = useState(false);
  const [adminEmailInput, setAdminEmailInput] = useState("");
  const [adminPassInput, setAdminPassInput] = useState("");
  const [currentAdminPass, setCurrentAdminPass] = useState("ayub 321");
  const [newAdminPassInput, setNewAdminPassInput] = useState(""); // For changing password
  
  const [isEditingProduct, setIsEditingProduct] = useState<Product | null>(null);
  const [isAddingProduct, setIsAddingProduct] = useState(false);
  const [newProduct, setNewProduct] = useState<Partial<Product>>({
    name: '', price: 0, category: 'T-SHIRTS', gender: 'MEN', images: [], description: '', status: 'Active', sizes: ['M', 'L', 'XL']
  });
  
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [showWelcomePopup, setShowWelcomePopup] = useState(false);
  
  // AI Chat State
  const [isChatOpen, setIsChatOpen] = useState(false);
  const [chatInput, setChatInput] = useState("");
  const [isTyping, setIsTyping] = useState(false);
  const [selectedLanguage, setSelectedLanguage] = useState<'EN' | 'AM' | null>(null);
  const [chatHistory, setChatHistory] = useState<{role: 'user' | 'ai', text: string}[]>([]);

  const [checkoutData, setCheckoutData] = useState({ name: '', email: '', address: '', phone: '', payment: 'Telebirr' as 'Telebirr' | 'CBE' });
  const chatEndRef = useRef<HTMLDivElement>(null);

  // Persistence
  useEffect(() => {
    const savedProducts = localStorage.getItem('dual_products_v7');
    const savedOrders = localStorage.getItem('dual_orders_v7');
    const savedPass = localStorage.getItem('dual_admin_pass_v7');
    const savedPayment = localStorage.getItem('dual_payment_info_v7');
    const savedDiscountUsed = localStorage.getItem('dual_discount_used_v7');
    const savedDiscountSettings = localStorage.getItem('dual_discount_settings_v7');
    const visited = localStorage.getItem('dual_visited_v7');

    if (savedProducts) setProducts(JSON.parse(savedProducts));
    if (savedOrders) setOrders(JSON.parse(savedOrders));
    if (savedPass) setCurrentAdminPass(savedPass);
    if (savedPayment) setPaymentInfo(JSON.parse(savedPayment));
    if (savedDiscountUsed) setHasUsedFirstOrderDiscount(JSON.parse(savedDiscountUsed));
    if (savedDiscountSettings) {
      const s = JSON.parse(savedDiscountSettings);
      setIsDiscountEnabled(s.enabled);
      setDiscountPercent(s.percent);
    }

    if (!visited) {
      setTimeout(() => setShowWelcomePopup(true), 1500);
      localStorage.setItem('dual_visited_v7', 'true');
    }

    // AI Initial
    setChatHistory([{ role: 'ai', text: "Hi 👋 Please choose a language / እባክዎን ቋንቋ ይምረጡ:\n1️⃣ English\n2️⃣ አማርኛ" }]);
  }, []);

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [chatHistory]);

  const subtotal = useMemo(() => cart.reduce((acc, item) => acc + item.price, 0), [cart]);
  const currentDiscountValue = useMemo(() => {
    if (isDiscountEnabled && !hasUsedFirstOrderDiscount) return (subtotal * discountPercent) / 100;
    return 0;
  }, [subtotal, isDiscountEnabled, hasUsedFirstOrderDiscount, discountPercent]);
  const finalTotal = subtotal - currentDiscountValue;

  const addToCart = (p: Product) => {
    if (p.status === 'Out of Stock') {
      alert("Artifact is depleted.");
      return;
    }
    setCart([...cart, p]);
    setIsCartOpen(true);
  };

  const removeFromCart = (idx: number) => setCart(cart.filter((_, i) => i !== idx));

  const updateOrderStatus = (orderId: string, newStatus: OrderStatus) => {
    const order = orders.find(o => o.id === orderId);
    if (!order) return;

    // Rule: Cannot Cancel if Delivered
    if (order.status === 'Delivered' && newStatus === 'Cancelled') {
      alert("Action Denied: Protocol forbids cancellation after delivery.");
      return;
    }

    const updated = orders.map(o => o.id === orderId ? { ...o, status: newStatus } : o);
    setOrders(updated);
    localStorage.setItem('dual_orders_v7', JSON.stringify(updated));
  };

  const deleteOrder = (orderId: string, e?: React.MouseEvent) => {
    if (e) {
      e.stopPropagation();
      e.preventDefault();
    }
    
    // Removed window.confirm to ensure instant action and prevent browser blocking
    setOrders(prevOrders => {
      const updated = prevOrders.filter(o => o.id !== orderId);
      localStorage.setItem('dual_orders_v7', JSON.stringify(updated));
      return updated;
    });
  };

  const handleAdminAuth = (e: React.FormEvent) => {
    e.preventDefault();
    if (ADMIN_EMAILS.includes(adminEmailInput.toLowerCase()) && adminPassInput === currentAdminPass) {
      setIsAdmin(true);
      setShowAdminLogin(false);
      setCurrentView('ADMIN');
    } else {
      alert("Unauthorized Access.");
    }
  };

  const handleChangePassword = () => {
    if (!newAdminPassInput.trim()) return;
    setCurrentAdminPass(newAdminPassInput);
    localStorage.setItem('dual_admin_pass_v7', newAdminPassInput);
    setNewAdminPassInput("");
    alert("Security Key Updated Successfully.");
  };

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>, isEditing: boolean) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;
    
    const base64Images: string[] = [];
    for (let i = 0; i < files.length; i++) {
      const file = files[i];
      const reader = new FileReader();
      const p = new Promise<string>((resolve) => {
        reader.onload = (event) => resolve(event.target?.result as string);
        reader.readAsDataURL(file);
      });
      base64Images.push(await p);
    }

    if (isEditing) {
      setIsEditingProduct(prev => prev ? { ...prev, images: [...prev.images, ...base64Images] } : null);
    } else {
      setNewProduct(prev => ({ ...prev, images: [...(prev.images || []), ...base64Images] }));
    }

    // Reset input value so onChange fires again if the same file is selected later
    e.target.value = '';
  };

  const handleAddProduct = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newProduct.name || !newProduct.price || !newProduct.images?.length) {
      alert("Name, Price, and Image required.");
      return;
    }
    const productToAdd: Product = {
      id: Date.now().toString(),
      name: newProduct.name,
      price: newProduct.price,
      image: newProduct.images[0],
      images: newProduct.images,
      category: (newProduct.category as Category),
      gender: (newProduct.gender as Gender),
      description: newProduct.description || 'Premium Artifact',
      status: newProduct.status || 'Active',
      sizes: newProduct.sizes || ['M', 'L']
    };
    const updated = [productToAdd, ...products];
    setProducts(updated);
    localStorage.setItem('dual_products_v7', JSON.stringify(updated));
    
    // Reset form
    setIsAddingProduct(false);
    setNewProduct({ name: '', price: 0, category: 'T-SHIRTS', gender: 'MEN', images: [], description: '', status: 'Active', sizes: ['M', 'L'] });
    
    // Redirect to Home to see the new item immediately
    setCurrentView('HOME');
  };

  const handleSaveEditProduct = (e: React.FormEvent) => {
    e.preventDefault();
    if (!isEditingProduct) return;
    const updated = products.map(p => p.id === isEditingProduct.id ? { ...isEditingProduct, image: isEditingProduct.images[0] } : p);
    setProducts(updated);
    localStorage.setItem('dual_products_v7', JSON.stringify(updated));
    setIsEditingProduct(null);
  };

  const handleDeleteProduct = (productId: string) => {
    // Removed confirm dialog to ensure instant deletion
    const updated = products.filter(p => p.id !== productId);
    setProducts(updated);
    localStorage.setItem('dual_products_v7', JSON.stringify(updated));
  };

  const handlePlaceOrder = (e: React.FormEvent) => {
    e.preventDefault();
    const newOrder: Order = {
      id: `DUAL-${Math.random().toString(36).substring(2, 7).toUpperCase()}`,
      customerName: checkoutData.name || "Guest Customer",
      customerEmail: checkoutData.email,
      address: checkoutData.address,
      phone: checkoutData.phone,
      items: [...cart],
      subtotal,
      discount: currentDiscountValue,
      total: finalTotal,
      status: 'Pending (Unpaid)',
      paymentMethod: checkoutData.payment,
      timestamp: Date.now()
    };
    const updated = [newOrder, ...orders];
    setOrders(updated);
    localStorage.setItem('dual_orders_v7', JSON.stringify(updated));
    if (currentDiscountValue > 0) {
      setHasUsedFirstOrderDiscount(true);
      localStorage.setItem('dual_discount_used_v7', 'true');
    }
    setCart([]);
    setCurrentView('SUCCESS');
  };

  const handleAiChat = async () => {
    if (!chatInput.trim()) return;
    const msg = chatInput;
    setChatInput("");
    setChatHistory(prev => [...prev, { role: 'user', text: msg }]);
    setIsTyping(true);

    if (!selectedLanguage) {
      if (msg.includes("1") || msg.toLowerCase().includes("english")) {
        setSelectedLanguage('EN');
        setChatHistory(prev => [...prev, { role: 'ai', text: "English mode active. How can I help? I'm short and clear." }]);
      } else if (msg.includes("2") || msg.includes("አማርኛ")) {
        setSelectedLanguage('AM');
        setChatHistory(prev => [...prev, { role: 'ai', text: "የአማርኛ ሁነታ በርቷል። ዛሬ እንዴት ልርዳዎት? መልሶቼ አጭር ናቸው።" }]);
      } else {
        setChatHistory(prev => [...prev, { role: 'ai', text: "Please choose 1 or 2." }]);
      }
      setIsTyping(false);
      return;
    }

    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      const systemPrompt = selectedLanguage === 'EN' 
        ? `You are Dual Concierge for 'Dual Store' streetwear. 
           Rules: 1. SHORT answers. 2. Logic: Order first -> We call -> Pay ONLY after call. 3. NO cancel after payment. 4. Addis Ababa ONLY.`
        : `አንተ የ 'Dual Store' ረዳት ነህ። ደንቦች፡ 1. አጭር መልሶች። 2. ቅደም ተከተል፡ ትዕዛዝ ያስገቡ -> ለማረጋገጥ እንደውላለን -> ካረጋገጥን በኋላ ይከፍላሉ። 3. ከክፍያ በኋላ መሰረዝ አይፈቀድም። 4. መላኪያ በአዲስ አበባ ብቻ ነው።`;

      const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: [{ role: 'user', parts: [{ text: `${systemPrompt}\nUser: ${msg}` }] }],
      });
      setChatHistory(prev => [...prev, { role: 'ai', text: response.text || "Contacting archive..." }]);
    } catch {
      setChatHistory(prev => [...prev, { role: 'ai', text: "Offline. Visit @dual_store2." }]);
    } finally {
      setIsTyping(false);
    }
  };

  const filteredProducts = products.filter(p => {
    if (p.status === 'Hidden' && !isAdmin) return false;
    const genderMatch = filterGender === 'ALL' || p.gender === filterGender;
    const categoryMatch = filterCategory === 'ALL' || p.category === filterCategory;
    return genderMatch && categoryMatch;
  });

  return (
    <div className="min-h-screen bg-[#050505] text-[#F0F0F0] font-sans selection:bg-[#3A6EFF] selection:text-white overflow-x-hidden">
      
      {/* Welcome Popup */}
      {showWelcomePopup && (
        <div className="fixed inset-0 z-[300] bg-black/95 flex items-center justify-center p-6 backdrop-blur-xl animate-in fade-in duration-500">
          <div className="bg-[#0A0A0A] border border-white/5 p-12 rounded-[3rem] max-w-lg w-full text-center relative shadow-4xl">
            <button onClick={() => setShowWelcomePopup(false)} className="absolute top-8 right-8 text-gray-500 hover:text-white"><X size={24} /></button>
            <div className="w-24 h-24 bg-[#3A6EFF] rounded-[2rem] mx-auto flex items-center justify-center text-white mb-10 shadow-[0_0_50px_rgba(58,110,255,0.4)]"><Zap size={44} className="fill-current" /></div>
            <h2 className="text-4xl font-black uppercase italic tracking-tighter mb-4">Dual Exclusive</h2>
            <p className="text-gray-400 mb-12 text-lg leading-relaxed font-medium">
              {isDiscountEnabled && !hasUsedFirstOrderDiscount 
                ? `Welcome. A ${discountPercent}% artifact discount will be applied to your first archive selection.` 
                : "The archive is open. Explore technical silhouettes for the modern polymath."}
            </p>
            <button onClick={() => { setShowWelcomePopup(false); setCurrentView('SHOP'); }} className="w-full bg-[#3A6EFF] text-white py-6 rounded-2xl font-black uppercase tracking-[0.2em] hover:bg-[#2A5EDF] transition-all shadow-xl shadow-[#3A6EFF]/20">Enter Archive</button>
          </div>
        </div>
      )}

      {/* Navigation */}
      <header className="fixed top-0 w-full z-50 bg-black/80 backdrop-blur-3xl border-b border-white/5 px-6 lg:px-16 py-6 flex items-center justify-between">
        <div className="flex items-center gap-16">
          <button onClick={() => setCurrentView('HOME')} className="text-2xl font-black tracking-tighter italic uppercase flex items-center gap-3 group">
            Dual <div className="w-10 h-[2px] bg-[#3A6EFF] group-hover:w-16 transition-all" /> Store
          </button>
          <nav className="hidden lg:flex items-center gap-10 text-[11px] font-black uppercase tracking-[0.3em]">
            <button onClick={() => { setFilterGender('MEN'); setCurrentView('SHOP'); }} className="hover:text-[#3A6EFF] transition-colors">Men</button>
            <button onClick={() => { setFilterGender('WOMEN'); setCurrentView('SHOP'); }} className="hover:text-[#3A6EFF] transition-colors">Women</button>
            <button onClick={() => { setFilterGender('ALL'); setCurrentView('SHOP'); }} className="hover:text-[#3A6EFF] transition-colors">Collection</button>
          </nav>
        </div>
        <div className="flex items-center gap-4 lg:gap-8">
          <div className="hidden sm:flex items-center gap-4">
             <a href={INSTAGRAM_URL} target="_blank" rel="noopener noreferrer" className="p-2 hover:bg-white/5 rounded-full transition-colors text-gray-500 hover:text-white">
                <Instagram size={20} />
             </a>
             <a href={TIKTOK_URL} target="_blank" rel="noopener noreferrer" className="p-2 hover:bg-white/5 rounded-full transition-colors text-gray-500 hover:text-white">
                <Music2 size={20} />
             </a>
          </div>
          <button onClick={() => isAdmin ? setCurrentView('ADMIN') : setShowAdminLogin(true)} className="p-2 hover:bg-white/5 rounded-full transition-colors"><Settings size={20} className="text-gray-500 hover:text-white" /></button>
          <button onClick={() => setIsCartOpen(true)} className="relative p-2 hover:bg-white/5 rounded-full transition-colors">
            <ShoppingBag size={22} />
            {cart.length > 0 && <span className="absolute -top-1 -right-1 bg-[#3A6EFF] text-white text-[9px] w-5 h-5 rounded-full flex items-center justify-center font-black animate-pulse">{cart.length}</span>}
          </button>
        </div>
      </header>

      <main className="pt-24 min-h-screen">
        {currentView === 'HOME' && (
          <div className="space-y-40 pb-40">
            {/* Hero */}
            <section className="px-6 lg:px-16 max-w-7xl mx-auto min-h-[85vh] flex flex-col justify-center">
              <div className="grid lg:grid-cols-2 gap-20 items-center">
                <div className="space-y-12">
                  <div className="space-y-6">
                    <p className="text-[#3A6EFF] text-[10px] font-black uppercase tracking-[0.6em] flex items-center gap-3">
                      <div className="w-3 h-3 rounded-full bg-[#3A6EFF] animate-ping" /> Addis Ababa MMXXV
                    </p>
                    <h1 className="text-8xl lg:text-[12rem] font-black leading-[0.75] italic tracking-tighter uppercase">
                      The <br /> <span className="text-white/10 group-hover:text-white transition-all duration-1000">Archive.</span>
                    </h1>
                  </div>
                  <p className="max-w-md text-xl text-gray-400 leading-relaxed font-medium italic border-l-2 border-[#3A6EFF] pl-8">
                    Architectural silhouettes. Premium materials. Designed for both sides of your modern existence.
                  </p>
                  <div className="flex flex-wrap gap-6 pt-6">
                    <button onClick={() => { setFilterGender('MEN'); setCurrentView('SHOP'); }} className="px-14 py-6 bg-white text-black font-black uppercase text-xs tracking-widest hover:bg-[#3A6EFF] hover:text-white transition-all">Shop Men</button>
                    <button onClick={() => { setFilterGender('WOMEN'); setCurrentView('SHOP'); }} className="px-14 py-6 border border-white/20 text-white font-black uppercase text-xs tracking-widest hover:bg-white hover:text-black transition-all">Shop Women</button>
                  </div>
                </div>
                <div className="relative hidden lg:block group">
                  <div className="aspect-[4/5] bg-zinc-950 rounded-[4rem] overflow-hidden shadow-4xl border border-white/5 group-hover:border-[#3A6EFF]/20 transition-all duration-700">
                    <img src="https://images.unsplash.com/photo-1552374196-1ab2a1c593e8?q=80&w=1887&auto=format&fit=crop" className="w-full h-full object-cover grayscale brightness-50 group-hover:grayscale-0 group-hover:brightness-100 transition-all duration-1000 hd-render" />
                  </div>
                  <div className="absolute -bottom-10 -left-10 p-10 bg-black/80 backdrop-blur-2xl rounded-[3rem] border border-white/10 max-w-xs shadow-3xl">
                       <p className="text-[10px] font-black uppercase tracking-widest text-[#3A6EFF] mb-3">Premium Entry</p>
                       <p className="text-lg font-bold uppercase italic leading-tight">Neural Knit V1 - Technical Weave</p>
                  </div>
                </div>
              </div>
            </section>

            {/* Latest Arrivals Section */}
            {products.length > 0 && (
              <section className="px-6 lg:px-16 max-w-7xl mx-auto">
                 <div className="flex items-center justify-between border-b border-white/5 pb-10 mb-16">
                    <h2 className="text-6xl font-black italic uppercase tracking-tighter">Latest Artifacts</h2>
                    <button onClick={() => setCurrentView('SHOP')} className="text-sm font-black uppercase tracking-widest text-gray-500 hover:text-white transition-colors flex items-center gap-3">View Archive <ArrowRight size={18}/></button>
                 </div>
                 <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
                    {products.slice(0, 3).map(p => (
                       <ProductCard key={p.id} product={p} onClick={() => { setSelectedProduct(p); setActiveImageIdx(0); setCurrentView('PRODUCT_DETAIL'); }} />
                    ))}
                 </div>
              </section>
            )}
          </div>
        )}

        {currentView === 'SHOP' && (
          <section className="px-6 lg:px-16 max-w-7xl mx-auto pb-40 animate-in fade-in duration-500">
            <div className="flex flex-col lg:flex-row gap-24">
              <aside className="w-full lg:w-72 space-y-16">
                <div className="space-y-10">
                  <h4 className="text-[10px] font-black uppercase tracking-[0.5em] text-[#3A6EFF]">Gender</h4>
                  <div className="flex flex-col gap-6">
                    {['ALL', 'MEN', 'WOMEN'].map(g => (
                      <button key={g} onClick={() => setFilterGender(g as any)} className={`text-left text-xs font-black uppercase tracking-[0.3em] transition-all ${filterGender === g ? 'text-white translate-x-4 border-l-2 border-[#3A6EFF] pl-4' : 'text-gray-500 hover:text-white'}`}>{g}</button>
                    ))}
                  </div>
                </div>
                <div className="space-y-10">
                  <h4 className="text-[10px] font-black uppercase tracking-[0.5em] text-[#3A6EFF]">Categories</h4>
                  <div className="flex flex-col gap-6">
                    {['ALL', 'T-SHIRTS', 'HOODIES', 'JACKETS', 'PANTS', 'ACCESSORIES'].map(c => (
                      <button key={c} onClick={() => setFilterCategory(c as any)} className={`text-left text-xs font-black uppercase tracking-[0.3em] transition-all ${filterCategory === c ? 'text-white translate-x-4 border-l-2 border-[#3A6EFF] pl-4' : 'text-gray-500 hover:text-white'}`}>{c}</button>
                    ))}
                  </div>
                </div>
              </aside>

              <div className="flex-grow space-y-16">
                <div className="flex items-center justify-between border-b border-white/5 pb-10">
                  <h1 className="text-6xl font-black italic uppercase tracking-tighter">Inventory <span className="text-[#3A6EFF] text-xl ml-4 font-normal">[{filteredProducts.length}]</span></h1>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-12">
                   {filteredProducts.map(p => (
                     <ProductCard key={p.id} product={p} onClick={() => { setSelectedProduct(p); setActiveImageIdx(0); setCurrentView('PRODUCT_DETAIL'); }} />
                   ))}
                </div>
              </div>
            </div>
          </section>
        )}

        {currentView === 'PRODUCT_DETAIL' && selectedProduct && (
          <section className="px-6 lg:px-16 max-w-7xl mx-auto pb-40 animate-in fade-in duration-700">
            {isLightboxOpen && (
              <div className="fixed inset-0 z-[500] bg-black/98 backdrop-blur-2xl flex items-center justify-center p-4 lg:p-12 animate-in zoom-in duration-300">
                <button onClick={() => setIsLightboxOpen(false)} className="absolute top-10 right-10 p-4 bg-white/5 rounded-full hover:bg-white/10 transition-colors z-[510]"><X size={32}/></button>
                <img src={selectedProduct.images?.[activeImageIdx] || selectedProduct.image} className="max-w-full max-h-full object-contain rounded-3xl shadow-[0_0_100px_rgba(58,110,255,0.2)] hd-render" />
                <div className="absolute bottom-10 left-1/2 -translate-x-1/2 text-[10px] font-black uppercase tracking-[0.5em] text-gray-500 bg-black/50 px-8 py-3 rounded-full border border-white/10">Ultra High Definition Archival View</div>
              </div>
            )}

            <div className="grid lg:grid-cols-2 gap-24 items-start">
              <div className="space-y-8 sticky top-32">
                <div className="aspect-[4/5] rounded-[4rem] overflow-hidden bg-zinc-950 border border-white/5 shadow-4xl relative group">
                  <img src={selectedProduct.images?.[activeImageIdx] || selectedProduct.image} className="w-full h-full object-cover transition-all duration-1000 cursor-zoom-in group-hover:scale-150 hd-render" />
                  <button onClick={() => setIsLightboxOpen(true)} className="absolute top-8 right-8 p-4 bg-black/60 rounded-full text-white opacity-0 group-hover:opacity-100 transition-all hover:scale-110 active:scale-95 shadow-xl backdrop-blur-md border border-white/10"><Maximize2 size={24}/></button>
                  <div className="absolute bottom-8 left-8 flex items-center gap-3 bg-black/60 backdrop-blur-md px-5 py-2 rounded-full border border-white/10 opacity-0 group-hover:opacity-100 transition-all">
                    <div className="w-2 h-2 rounded-full bg-[#3A6EFF] animate-pulse" />
                    <span className="text-[9px] font-black uppercase tracking-widest text-white">4K Detail View</span>
                  </div>
                  {selectedProduct.status === 'Out of Stock' && (
                    <div className="absolute inset-0 bg-black/80 backdrop-blur-md flex items-center justify-center">
                       <p className="text-3xl font-black uppercase italic tracking-[0.3em] text-red-500 border-2 border-red-500/20 px-10 py-5 rounded-3xl">Depleted</p>
                    </div>
                  )}
                </div>
                <div className="flex gap-4 overflow-x-auto pb-6 scrollbar-hide">
                  {selectedProduct.images.map((img, idx) => (
                    <button key={idx} onClick={() => setActiveImageIdx(idx)} className={`w-24 h-32 rounded-2xl overflow-hidden shrink-0 border-2 transition-all ${activeImageIdx === idx ? 'border-[#3A6EFF] scale-105' : 'border-transparent opacity-40 hover:opacity-100'}`}>
                      <img src={img} className="w-full h-full object-cover hd-render" />
                    </button>
                  ))}
                </div>
              </div>
              <div className="flex flex-col justify-center space-y-14 py-10">
                <div className="space-y-6">
                  <p className="text-[#3A6EFF] text-[10px] font-black uppercase tracking-[0.5em] flex items-center gap-4">
                    <span>{selectedProduct.gender} &bull; {selectedProduct.category}</span>
                    <span className="bg-[#3A6EFF]/10 text-[#3A6EFF] px-3 py-1 rounded-md border border-[#3A6EFF]/20">HD ARCHIVE</span>
                  </p>
                  <h1 className="text-7xl lg:text-9xl font-black italic uppercase tracking-tighter leading-[0.85]">{selectedProduct.name}</h1>
                  <p className="text-5xl font-black text-white italic tracking-tighter">ETB {selectedProduct.price.toLocaleString()}</p>
                </div>
                <p className="text-gray-400 text-xl leading-relaxed max-w-lg font-medium italic border-l-2 border-white/10 pl-8">
                  {selectedProduct.description}
                </p>
                <div className="space-y-8">
                  <h4 className="text-[10px] font-black uppercase tracking-[0.4em] text-[#3A6EFF]">Sizing Protocols</h4>
                  <div className="flex flex-wrap gap-5">
                    {selectedProduct.sizes.map(s => (
                      <button key={s} className="w-20 h-20 border border-white/10 rounded-3xl flex items-center justify-center font-black uppercase hover:bg-white hover:text-black transition-all active:scale-90 text-sm tracking-widest">{s}</button>
                    ))}
                  </div>
                </div>
                <div className="pt-10 space-y-8">
                  <button 
                    disabled={selectedProduct.status === 'Out of Stock'}
                    onClick={() => addToCart(selectedProduct)} 
                    className={`w-full py-8 rounded-[2rem] font-black uppercase tracking-[0.2em] text-sm transition-all shadow-3xl ${selectedProduct.status === 'Out of Stock' ? 'bg-zinc-900 text-gray-700 cursor-not-allowed' : 'bg-[#3A6EFF] text-white hover:scale-[1.02] active:scale-[0.98] shadow-[#3A6EFF]/20'}`}
                  >
                    {selectedProduct.status === 'Out of Stock' ? 'Archive Depleted' : 'Acquire Artifact'}
                  </button>
                  <button onClick={() => setCurrentView('SHOP')} className="w-full text-[10px] font-black uppercase tracking-widest text-gray-600 hover:text-white transition-colors text-center flex items-center justify-center gap-3">
                    <ChevronLeft size={16}/> Return to Index
                  </button>
                </div>
              </div>
            </div>
          </section>
        )}

        {currentView === 'CHECKOUT' && (
          <section className="px-6 lg:px-16 max-w-4xl mx-auto pb-40 animate-in slide-in-from-bottom duration-700">
             <div className="bg-[#0A0A0A] border border-white/5 p-12 lg:p-20 rounded-[4rem] shadow-4xl space-y-16">
                <header className="space-y-6 text-center">
                   <h2 className="text-6xl font-black italic uppercase tracking-tighter">Settlement</h2>
                   <p className="text-gray-500 font-medium italic">Complete the requisition to secure your garments.</p>
                </header>

                <div className="grid lg:grid-cols-2 gap-16">
                   <form onSubmit={handlePlaceOrder} className="space-y-8">
                      {/* Removed Full Designation Field as requested */}
                      
                      <div className="space-y-4">
                        <label className="text-[10px] font-black uppercase tracking-widest px-4 text-gray-500">Contact Number (For Confirmation Call)</label>
                        <input required type="tel" className="w-full bg-white/5 border border-white/5 rounded-2xl p-6 outline-none focus:border-[#3A6EFF] transition-all font-bold" value={checkoutData.phone} onChange={e => setCheckoutData({...checkoutData, phone: e.target.value})} />
                      </div>
                      <div className="space-y-4">
                        <label className="text-[10px] font-black uppercase tracking-widest px-4 text-gray-500">Addis Ababa Address</label>
                        <input required className="w-full bg-white/5 border border-white/5 rounded-2xl p-6 outline-none focus:border-[#3A6EFF] transition-all font-bold" value={checkoutData.address} onChange={e => setCheckoutData({...checkoutData, address: e.target.value})} />
                      </div>
                      <div className="space-y-4">
                        <label className="text-[10px] font-black uppercase tracking-widest px-4 text-gray-500">Payment Protocol</label>
                        <div className="grid grid-cols-2 gap-4">
                           {['Telebirr', 'CBE'].map(p => (
                             <button key={p} type="button" onClick={() => setCheckoutData({...checkoutData, payment: p as any})} className={`py-6 rounded-2xl font-black uppercase text-[10px] tracking-widest transition-all ${checkoutData.payment === p ? 'bg-[#3A6EFF] text-white' : 'bg-white/5 text-gray-500 border border-white/5'}`}>{p}</button>
                           ))}
                        </div>
                      </div>
                      <button type="submit" className="w-full bg-[#3A6EFF] text-white py-8 rounded-3xl font-black uppercase tracking-[0.2em] text-xs hover:scale-[1.02] shadow-3xl shadow-[#3A6EFF]/20">Place Order</button>
                   </form>

                   <div className="space-y-12">
                      <div className="p-10 bg-white/5 rounded-[3rem] space-y-8 border border-white/5">
                         <h4 className="text-xl font-black italic uppercase">Order Review</h4>
                         <div className="space-y-4">
                            {cart.map((item, i) => (
                              <div key={i} className="flex justify-between items-center text-sm font-bold uppercase italic tracking-tighter">
                                <span className="text-gray-400">{item.name}</span>
                                <span>ETB {item.price.toLocaleString()}</span>
                              </div>
                            ))}
                         </div>
                         <div className="pt-8 border-t border-white/5 space-y-4">
                            <div className="flex justify-between text-[10px] font-black uppercase text-gray-600"><span>Subtotal</span><span>ETB {subtotal.toLocaleString()}</span></div>
                            {currentDiscountValue > 0 && <div className="flex justify-between text-[10px] font-black uppercase text-green-500"><span>Archive Discount ({discountPercent}%)</span><span>- ETB {currentDiscountValue.toLocaleString()}</span></div>}
                            <div className="flex justify-between text-4xl font-black italic text-[#3A6EFF]"><span>Total</span><span>ETB {finalTotal.toLocaleString()}</span></div>
                         </div>
                      </div>

                      <div className="p-8 bg-amber-500/5 border border-amber-500/20 rounded-3xl space-y-6">
                         <div className="flex items-center gap-4 text-amber-500"><AlertCircle size={24}/> <span className="font-black uppercase tracking-widest text-xs">Protocol Notice</span></div>
                         <div className="space-y-4 italic font-medium leading-relaxed">
                            <p className="text-sm">“After placing your order, we will call you to confirm. Payment is made after confirmation. Orders cannot be cancelled after payment.”</p>
                            <p className="text-sm">“ትዕዛዝዎን ካስገቡ በኋላ ለማረጋገጥ እንደደውልዎታለን። ክፍያ ከማረጋገጫ በኋላ ይከፈላል። ከክፍያ በኋላ መሰረዝ አይከለከልም።”</p>
                         </div>
                      </div>
                   </div>
                </div>
             </div>
          </section>
        )}

        {currentView === 'SUCCESS' && (
          <section className="flex flex-col items-center justify-center py-40 px-6 text-center space-y-10 animate-in zoom-in duration-700">
             <div className="w-32 h-32 bg-green-500 rounded-[2.5rem] flex items-center justify-center text-white shadow-[0_0_80px_rgba(34,197,94,0.4)]"><CheckCircle size={60} /></div>
             <div className="space-y-4">
                <h1 className="text-6xl font-black italic uppercase tracking-tighter">Requisition Received</h1>
                <p className="text-gray-400 max-w-md mx-auto text-lg leading-relaxed italic font-medium">A Dual representative will initiate contact shortly to finalize details and confirm the transfer. 24/7 Support via @dual_store2.</p>
             </div>
             <button onClick={() => setCurrentView('SHOP')} className="px-12 py-6 bg-white text-black font-black uppercase text-xs tracking-widest hover:bg-[#3A6EFF] hover:text-white transition-all">Back to Archive</button>
          </section>
        )}

        {currentView === 'ADMIN' && (
          <section className="px-6 lg:px-16 max-w-7xl mx-auto pb-40 space-y-24 animate-in fade-in duration-500">
            
            {/* Add / Edit Product Modal */}
            {(isAddingProduct || isEditingProduct) && (
              <div className="fixed inset-0 z-[400] bg-black/98 backdrop-blur-2xl flex items-center justify-center p-6 animate-in fade-in duration-300 overflow-y-auto">
                 <div className="bg-[#0A0A0A] border border-white/5 p-12 lg:p-16 rounded-[4rem] w-full max-w-4xl space-y-12 shadow-4xl my-10">
                    <div className="flex items-center justify-between">
                       <h2 className="text-4xl font-black italic uppercase tracking-tighter flex items-center gap-4">
                        {isEditingProduct ? <Settings className="text-[#3A6EFF]" size={36}/> : <PlusCircle className="text-[#3A6EFF]" size={36}/>}
                        {isEditingProduct ? "Modify Garment" : "New Archive Entry"}
                       </h2>
                       <button onClick={() => { setIsAddingProduct(false); setIsEditingProduct(null); }} className="p-4 bg-white/5 rounded-full hover:bg-white/10 transition-colors"><X size={24}/></button>
                    </div>
                    
                    <form onSubmit={isEditingProduct ? handleSaveEditProduct : handleAddProduct} className="grid grid-cols-1 md:grid-cols-2 gap-10">
                       <div className="space-y-4">
                          <label className="text-[10px] font-black uppercase tracking-widest px-4 text-gray-500">Designation</label>
                          <input required value={isEditingProduct ? isEditingProduct.name : newProduct.name} onChange={e => isEditingProduct ? setIsEditingProduct({...isEditingProduct, name: e.target.value}) : setNewProduct({...newProduct, name: e.target.value})} className="w-full bg-white/5 border border-white/5 rounded-2xl p-6 outline-none focus:border-[#3A6EFF] transition-all font-bold" placeholder="E.g. Neural Bomber" />
                       </div>
                       <div className="space-y-4">
                          <label className="text-[10px] font-black uppercase tracking-widest px-4 text-gray-500">Valuation (ETB)</label>
                          <input required type="number" value={isEditingProduct ? isEditingProduct.price : newProduct.price} onChange={e => isEditingProduct ? setIsEditingProduct({...isEditingProduct, price: parseInt(e.target.value)}) : setNewProduct({...newProduct, price: parseInt(e.target.value)})} className="w-full bg-white/5 border border-white/5 rounded-2xl p-6 outline-none focus:border-[#3A6EFF] transition-all font-bold" />
                       </div>
                       <div className="space-y-4">
                          <label className="text-[10px] font-black uppercase tracking-widest px-4 text-gray-500">Gender Node</label>
                          <select value={isEditingProduct ? isEditingProduct.gender : newProduct.gender} onChange={e => isEditingProduct ? setIsEditingProduct({...isEditingProduct, gender: e.target.value as Gender}) : setNewProduct({...newProduct, gender: e.target.value as Gender})} className="w-full bg-white/5 border border-white/5 rounded-2xl p-6 outline-none focus:border-[#3A6EFF] transition-all font-black uppercase tracking-widest text-[10px]">
                             <option value="MEN">MEN</option><option value="WOMEN">WOMEN</option><option value="UNISEX">UNISEX</option>
                          </select>
                       </div>
                       <div className="space-y-4">
                          <label className="text-[10px] font-black uppercase tracking-widest px-4 text-gray-500">Category Cluster</label>
                          <select value={isEditingProduct ? isEditingProduct.category : newProduct.category} onChange={e => isEditingProduct ? setIsEditingProduct({...isEditingProduct, category: e.target.value as Category}) : setNewProduct({...newProduct, category: e.target.value as Category})} className="w-full bg-white/5 border border-white/5 rounded-2xl p-6 outline-none focus:border-[#3A6EFF] transition-all font-black uppercase tracking-widest text-[10px]">
                             {['T-SHIRTS', 'HOODIES', 'JACKETS', 'PANTS', 'ACCESSORIES'].map(c => <option key={c} value={c}>{c}</option>)}
                          </select>
                       </div>
                       <div className="md:col-span-2 space-y-6">
                          <label className="text-[10px] font-black uppercase tracking-widest px-4 text-gray-500 flex items-center gap-3"><Upload size={14}/> Archive Visuals (High-Quality Upload)</label>
                          <div className="w-full min-h-[160px] bg-white/5 border-2 border-dashed border-white/10 rounded-[2.5rem] p-10 flex flex-col items-center justify-center hover:border-[#3A6EFF]/50 transition-all group relative cursor-pointer" onClick={() => document.getElementById('file-upload')?.click()}>
                             <input id="file-upload" type="file" multiple accept="image/*" onChange={(e) => handleFileChange(e, !!isEditingProduct)} className="hidden" />
                             <Upload size={40} className="text-gray-600 group-hover:text-[#3A6EFF] transition-colors mb-4" />
                             <p className="text-xs font-black uppercase tracking-widest text-gray-500">Select Multiple Images for HD Gallery</p>
                          </div>
                          <div className="flex flex-wrap gap-4">
                             {(isEditingProduct ? isEditingProduct.images : (newProduct.images || [])).map((img, idx) => (
                               <div key={idx} className="w-24 h-32 rounded-2xl overflow-hidden relative group border border-white/10 shadow-xl">
                                 <img src={img} className="w-full h-full object-cover hd-render" />
                                 <div className="absolute top-1 left-1 bg-black/60 backdrop-blur-md px-1.5 py-0.5 rounded text-[7px] font-black text-white uppercase tracking-tighter">HD</div>
                                 <button type="button" onClick={() => isEditingProduct ? setIsEditingProduct({...isEditingProduct, images: isEditingProduct.images.filter((_, i) => i !== idx)}) : setNewProduct({...newProduct, images: newProduct.images?.filter((_, i) => i !== idx)})} className="absolute top-2 right-2 bg-red-500 text-white p-1.5 rounded-lg opacity-0 group-hover:opacity-100 transition-all"><X size={12}/></button>
                               </div>
                             ))}
                          </div>
                       </div>
                       <div className="md:col-span-2 space-y-4">
                          <label className="text-[10px] font-black uppercase tracking-widest px-4 text-gray-500">Metadata (Description)</label>
                          <textarea value={isEditingProduct ? isEditingProduct.description : newProduct.description} onChange={e => isEditingProduct ? setIsEditingProduct({...isEditingProduct, description: e.target.value}) : setNewProduct({...newProduct, description: e.target.value})} className="w-full bg-white/5 border border-white/5 rounded-2xl p-6 outline-none focus:border-[#3A6EFF] transition-all font-medium italic h-40" placeholder="Product story..." />
                       </div>
                       <div className="md:col-span-2">
                          <button type="submit" className="w-full bg-[#3A6EFF] text-white py-8 rounded-[2rem] font-black uppercase tracking-[0.2em] text-xs shadow-3xl shadow-[#3A6EFF]/20">Commit HD Archive Changes</button>
                       </div>
                    </form>
                 </div>
              </div>
            )}

            <div className="flex flex-col lg:flex-row items-center justify-between gap-8 border-b border-white/5 pb-16">
               <div className="space-y-2">
                 <h1 className="text-6xl font-black italic uppercase tracking-tighter">Command Center</h1>
                 <p className="text-[#3A6EFF] text-[10px] font-black uppercase tracking-[0.6em]">Validated Authority Access</p>
               </div>
               <div className="flex items-center gap-6">
                 <button onClick={() => { setIsAdmin(false); setCurrentView('HOME'); }} className="px-10 py-5 bg-red-500/10 text-red-500 rounded-2xl hover:bg-red-500 hover:text-white transition-all font-black text-[10px] uppercase tracking-widest flex items-center gap-3 border border-red-500/10"><LogOut size={18}/> Terminate Session</button>
               </div>
            </div>

            <div className="grid lg:grid-cols-12 gap-16">
               <div className="lg:col-span-4 space-y-12">
                  <div className="p-12 bg-zinc-950 rounded-[3rem] border border-white/5 space-y-10 shadow-4xl">
                    <p className="text-[10px] font-black uppercase tracking-[0.4em] text-gray-500">Registry Settlement</p>
                    <h3 className="text-6xl font-black italic">ETB {orders.filter(o => o.status === 'Paid').reduce((s,o)=>s+o.total,0).toLocaleString()}</h3>
                    <div className="grid grid-cols-2 gap-8 pt-10 border-t border-white/5">
                      <div><p className="text-[9px] font-black text-gray-600 uppercase mb-2">Total Orders</p><p className="text-3xl font-black italic">{orders.length}</p></div>
                      <div><p className="text-[9px] font-black text-gray-600 uppercase mb-2">Garments</p><p className="text-3xl font-black italic">{products.length}</p></div>
                    </div>
                  </div>

                  {/* Settings Panel */}
                  <div className="p-12 bg-zinc-950 rounded-[3rem] border border-white/5 space-y-10 shadow-4xl">
                     <h4 className="text-xl font-black italic uppercase flex items-center gap-4"><Settings size={22} className="text-[#3A6EFF]"/> Global Config</h4>
                     <div className="space-y-8">
                        {/* Password Change Section */}
                        <div className="space-y-3 pb-6 border-b border-white/5">
                           <label className="text-[9px] font-black uppercase tracking-widest text-gray-600">Security Protocols (Update Password)</label>
                           <div className="flex gap-2">
                             <input type="password" value={newAdminPassInput} onChange={e => setNewAdminPassInput(e.target.value)} placeholder="New Key..." className="w-full bg-white/5 border border-white/5 rounded-xl p-4 font-black text-xs" />
                             <button onClick={handleChangePassword} className="bg-[#3A6EFF] text-white px-4 rounded-xl font-black uppercase text-[10px] tracking-widest hover:bg-[#2A5EDF]">Update</button>
                           </div>
                        </div>

                        <div className="flex items-center justify-between">
                           <span className="text-xs font-black uppercase tracking-widest text-gray-400">First-Time Discount</span>
                           <button onClick={() => setIsDiscountEnabled(!isDiscountEnabled)} className={`w-14 h-8 rounded-full transition-all relative ${isDiscountEnabled ? 'bg-[#3A6EFF]' : 'bg-zinc-800'}`}><div className={`w-6 h-6 bg-white rounded-full absolute top-1 transition-all ${isDiscountEnabled ? 'right-1' : 'left-1'}`} /></button>
                        </div>
                        <div className="space-y-3">
                           <label className="text-[9px] font-black uppercase tracking-widest text-gray-600">Discount Percentage</label>
                           <input type="number" value={discountPercent} onChange={e => setDiscountPercent(parseInt(e.target.value))} className="w-full bg-white/5 border border-white/5 rounded-xl p-4 font-black" />
                        </div>
                        <div className="space-y-3">
                           <label className="text-[9px] font-black uppercase tracking-widest text-gray-600">Telebirr Wallet</label>
                           <input value={paymentInfo.telebirr} onChange={e => setPaymentInfo({...paymentInfo, telebirr: e.target.value})} className="w-full bg-white/5 border border-white/5 rounded-xl p-4 font-black text-xs" />
                        </div>
                        <div className="space-y-3">
                           <label className="text-[9px] font-black uppercase tracking-widest text-gray-600">CBE Account</label>
                           <input value={paymentInfo.cbe} onChange={e => setPaymentInfo({...paymentInfo, cbe: e.target.value})} className="w-full bg-white/5 border border-white/5 rounded-xl p-4 font-black text-xs" />
                        </div>
                     </div>
                  </div>
               </div>

               <div className="lg:col-span-8 space-y-24">
                  <div className="p-14 bg-zinc-950 rounded-[4rem] border border-white/5 space-y-12 shadow-4xl">
                    <div className="flex items-center justify-between">
                       <h4 className="text-3xl font-black italic uppercase flex items-center gap-6"><ClipboardList size={34} className="text-[#3A6EFF]"/> Order Registry</h4>
                    </div>
                    <div className="space-y-10">
                      {orders.map(o => (
                        <div key={o.id} className="p-10 bg-white/5 rounded-[3rem] border border-white/5 space-y-10 group hover:bg-white/[0.08] transition-all">
                           <div className="flex flex-col md:flex-row justify-between gap-8">
                             <div className="space-y-3">
                               <div className="flex items-center gap-4">
                                 <span className="text-[10px] font-black text-[#3A6EFF] uppercase tracking-[0.3em]">{o.id}</span>
                                 <span className={`px-4 py-1 rounded-full text-[9px] font-black uppercase tracking-widest ${o.status === 'Paid' ? 'bg-green-500/10 text-green-500' : o.status === 'Cancelled' ? 'bg-red-500/10 text-red-500' : 'bg-amber-500/10 text-amber-500'}`}>{o.status}</span>
                               </div>
                               <h5 className="text-4xl font-black italic uppercase tracking-tighter">{o.customerName}</h5>
                               <p className="text-sm font-bold text-gray-500 flex items-center gap-3"><Phone size={16}/> {o.phone}</p>
                             </div>
                             <div className="text-right space-y-2">
                               <p className="text-4xl font-black italic text-white">ETB {o.total.toLocaleString()}</p>
                               <p className="text-[10px] font-black uppercase text-gray-600 tracking-widest">{o.paymentMethod}</p>
                             </div>
                           </div>
                           <div className="flex flex-wrap gap-4 pt-10 border-t border-white/5">
                              {['Pending', 'Confirmed', 'Paid', 'Shipped', 'Delivered', 'Cancelled'].map(s => (
                                <button 
                                  key={s} 
                                  onClick={() => updateOrderStatus(o.id, s as any)} 
                                  disabled={o.status === 'Delivered' && s === 'Cancelled'}
                                  className={`px-6 py-3 rounded-xl text-[9px] font-black uppercase tracking-widest transition-all ${
                                    o.status.includes(s) 
                                      ? 'bg-[#3A6EFF] text-white shadow-xl' 
                                      : (o.status === 'Delivered' && s === 'Cancelled')
                                        ? 'bg-zinc-800 text-gray-700 cursor-not-allowed opacity-50'
                                        : 'bg-white/5 text-gray-500 hover:text-white'
                                  }`}
                                >
                                  {s}
                                </button>
                              ))}
                              <div className="ml-auto flex gap-3 relative z-10">
                                <button type="button" onClick={(e) => deleteOrder(o.id, e)} className="p-4 bg-red-500/5 text-red-500 rounded-2xl hover:bg-red-500 hover:text-white transition-all border border-red-500/10 cursor-pointer relative z-20 pointer-events-auto"><Trash2 size={20}/></button>
                              </div>
                           </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="p-14 bg-zinc-950 rounded-[4rem] border border-white/5 space-y-12 shadow-4xl">
                    <div className="flex items-center justify-between">
                       <h4 className="text-3xl font-black italic uppercase flex items-center gap-6"><Package size={34} className="text-[#3A6EFF]"/> Archive Collection</h4>
                       <button onClick={() => setIsAddingProduct(true)} className="px-10 py-5 bg-[#3A6EFF] text-white rounded-[2rem] text-[10px] font-black uppercase tracking-widest shadow-xl flex items-center gap-3 hover:scale-105 transition-all"><Plus size={20}/> New Entry</button>
                    </div>
                    <div className="grid md:grid-cols-2 gap-10">
                       {products.map(p => (
                         <div key={p.id} className="p-8 bg-white/5 rounded-[3rem] border border-white/5 flex items-center gap-8 group relative overflow-hidden">
                           <div className="w-24 h-32 bg-black rounded-3xl overflow-hidden border border-white/10 shrink-0 shadow-2xl">
                              <img src={p.images?.[0] || p.image} className="w-full h-full object-cover group-hover:scale-110 transition-all duration-1000 hd-render" />
                           </div>
                           <div className="flex-grow space-y-2">
                             <div className="flex items-center gap-3">
                               <p className="text-2xl font-black uppercase italic tracking-tighter truncate leading-none">{p.name}</p>
                             </div>
                             <p className="text-lg font-black text-[#3A6EFF] italic">ETB {p.price.toLocaleString()}</p>
                             <div className="flex gap-2">
                               <button onClick={() => setIsEditingProduct(p)} className="p-3 text-gray-500 hover:text-white transition-colors"><Settings size={20}/></button>
                               <button onClick={() => handleDeleteProduct(p.id)} className="p-3 text-red-500/20 hover:text-red-500 transition-colors"><Trash2 size={20}/></button>
                             </div>
                           </div>
                         </div>
                       ))}
                    </div>
                  </div>
               </div>
            </div>
          </section>
        )}
      </main>

      {/* Cart Drawer */}
      {isCartOpen && (
        <div className="fixed inset-0 z-[250] bg-black/90 flex justify-end animate-in fade-in duration-300">
           <div className="w-full max-w-md h-full bg-[#0A0A0A] p-12 flex flex-col shadow-4xl border-l border-white/5 animate-in slide-in-from-right duration-500">
              <header className="flex items-center justify-between mb-16 border-b border-white/5 pb-10">
                 <h2 className="text-5xl font-black italic uppercase tracking-tighter">Basket</h2>
                 <button onClick={() => setIsCartOpen(false)} className="hover:rotate-90 transition-all duration-500"><X size={40} /></button>
              </header>
              <div className="flex-grow overflow-y-auto space-y-12 pr-4 custom-scrollbar">
                {cart.length === 0 ? (
                  <div className="h-full flex flex-col items-center justify-center text-center space-y-8 opacity-20 italic">
                    <ShoppingBag size={120} />
                    <p className="text-xs font-black uppercase tracking-[0.4em]">Empty Registry</p>
                  </div>
                ) : cart.map((item, i) => (
                  <div key={i} className="flex gap-8 items-center border-b border-white/5 pb-12 group">
                    <div className="w-24 h-32 bg-black rounded-3xl overflow-hidden border border-white/10 shadow-xl">
                      <img src={item.image} className="w-full h-full object-cover group-hover:scale-110 transition-all duration-700 hd-render" />
                    </div>
                    <div className="flex-grow space-y-2">
                      <h4 className="text-2xl font-black italic uppercase tracking-tighter leading-none">{item.name}</h4>
                      <p className="text-xl font-black italic text-[#3A6EFF]">ETB {item.price.toLocaleString()}</p>
                    </div>
                    <button onClick={() => removeFromCart(i)} className="text-gray-700 hover:text-red-500 transition-colors"><Trash2 size={24} /></button>
                  </div>
                ))}
              </div>
              {cart.length > 0 && (
                <footer className="pt-12 border-t border-white/5 mt-10 space-y-12">
                   <div className="space-y-6">
                      <div className="flex justify-between items-end">
                         <span className="text-[10px] font-black uppercase text-gray-600 tracking-widest">Archive Total</span>
                         <span className="text-6xl font-black italic leading-none">ETB {finalTotal.toLocaleString()}</span>
                      </div>
                   </div>
                   <button onClick={() => { setIsCartOpen(false); setCurrentView('CHECKOUT'); }} className="w-full bg-[#3A6EFF] text-white py-8 rounded-[2rem] font-black uppercase tracking-[0.2em] text-xs shadow-3xl">Commit Requisition</button>
                </footer>
              )}
           </div>
        </div>
      )}

      {/* AI FAB */}
      <button onClick={() => setIsChatOpen(!isChatOpen)} className="fixed bottom-12 right-12 z-[200] w-24 h-24 bg-[#3A6EFF] text-white rounded-[2.5rem] shadow-4xl flex items-center justify-center hover:scale-110 active:scale-90 transition-all group">
        {isChatOpen ? <X size={40} /> : <MessageSquare size={40} className="group-hover:animate-bounce" />}
      </button>

      {isChatOpen && (
        <div className="fixed bottom-40 right-12 z-[200] w-full max-w-[440px] h-[700px] bg-[#0A0A0A] border border-white/5 rounded-[4rem] shadow-4xl flex flex-col overflow-hidden animate-in slide-in-from-bottom duration-500">
           <header className="p-10 bg-[#3A6EFF]/5 flex items-center gap-8 border-b border-white/5">
              <div className="w-20 h-20 bg-[#3A6EFF] rounded-[2rem] flex items-center justify-center text-white shadow-2xl"><Sparkles size={40} className="fill-current" /></div>
              <div>
                <p className="text-2xl font-black italic uppercase tracking-tighter">Dual Concierge</p>
                <div className="flex items-center gap-3 mt-1"><div className="w-2.5 h-2.5 rounded-full bg-green-500 animate-pulse" /><span className="text-[10px] font-black text-green-500 uppercase tracking-widest">Realtime Support</span></div>
              </div>
           </header>
           <div className="flex-grow p-10 overflow-y-auto space-y-10 custom-scrollbar">
              {chatHistory.map((m, i) => (
                <div key={i} className={`flex ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                  <div className={`max-w-[85%] p-8 rounded-[2.5rem] text-sm font-bold leading-relaxed shadow-xl italic ${m.role === 'user' ? 'bg-[#3A6EFF] text-white rounded-tr-none' : 'bg-white/5 text-gray-300 rounded-tl-none border border-white/5'}`}>{m.text}</div>
                </div>
              ))}
              {isTyping && <div className="text-[10px] font-black uppercase tracking-widest text-[#3A6EFF] animate-pulse">Consulting archive...</div>}
              <div ref={chatEndRef} />
           </div>
           <footer className="p-10 border-t border-white/5 bg-black/50 backdrop-blur-3xl">
              <div className="flex gap-4 p-4 bg-white/5 rounded-[2rem] border border-white/5 focus-within:border-[#3A6EFF] transition-all">
                <input className="flex-grow bg-transparent px-6 text-sm font-black italic outline-none" placeholder="Ask about the archive..." value={chatInput} onChange={e => setChatInput(e.target.value)} onKeyDown={e => e.key === 'Enter' && handleAiChat()} />
                <button onClick={handleAiChat} className="p-6 bg-[#3A6EFF] text-white rounded-2xl transition-all shadow-xl shadow-[#3A6EFF]/20 hover:scale-105 active:scale-95"><Send size={24} /></button>
              </div>
           </footer>
        </div>
      )}

      {/* Admin Login */}
      {showAdminLogin && (
        <div className="fixed inset-0 z-[400] bg-black/98 flex items-center justify-center p-6 backdrop-blur-3xl animate-in fade-in duration-500">
           <div className="bg-[#0A0A0A] border border-white/5 p-16 lg:p-24 rounded-[5rem] w-full max-w-xl text-center space-y-14 shadow-4xl">
              <div className="w-28 h-28 bg-[#3A6EFF] rounded-[2.5rem] mx-auto flex items-center justify-center text-white shadow-[0_0_100px_rgba(58,110,255,0.3)]"><Lock size={50} /></div>
              <h2 className="text-5xl font-black italic uppercase tracking-tighter">Authority</h2>
              <form onSubmit={handleAdminAuth} className="space-y-8 text-left">
                <div className="space-y-4">
                  <label className="text-[10px] font-black uppercase tracking-widest px-4 text-gray-500">Node Identifier</label>
                  <input required type="email" value={adminEmailInput} onChange={e => setAdminEmailInput(e.target.value)} className="w-full bg-white/5 border border-white/5 rounded-3xl p-8 outline-none focus:border-[#3A6EFF] transition-all font-black text-lg" />
                </div>
                <div className="space-y-4">
                  <label className="text-[10px] font-black uppercase tracking-widest px-4 text-gray-500">Security Key</label>
                  <input required type="password" value={adminPassInput} onChange={e => setAdminPassInput(e.target.value)} className="w-full bg-white/5 border border-white/5 rounded-3xl p-8 outline-none focus:border-[#3A6EFF] transition-all font-black text-lg" />
                </div>
                <button type="submit" className="w-full bg-[#3A6EFF] text-white py-8 rounded-3xl font-black uppercase tracking-[0.2em] text-xs">Establish Link</button>
              </form>
              <button onClick={() => setShowAdminLogin(false)} className="text-[10px] font-black uppercase tracking-widest text-gray-700 hover:text-white transition-colors underline underline-offset-8 decoration-gray-800">Abort Protocol</button>
           </div>
        </div>
      )}

      {/* Global Footer */}
      <footer className="bg-black py-40 px-6 lg:px-16 border-t border-white/5 text-center space-y-16">
         <h2 className="text-8xl font-black italic uppercase tracking-tighter opacity-10">Dual Store</h2>
         <div className="flex justify-center gap-16 text-gray-600">
            <a href={INSTAGRAM_URL} target="_blank" rel="noopener noreferrer">
              <Instagram className="hover:text-[#3A6EFF] transition-colors cursor-pointer" size={32} />
            </a>
            <a href={TIKTOK_URL} target="_blank" rel="noopener noreferrer">
              <Music2 className="hover:text-[#3A6EFF] transition-colors cursor-pointer" size={32} />
            </a>
         </div>
         <p className="text-[10px] font-black uppercase tracking-[0.8em] text-white/5 italic">&copy; MMXXV Dual Store Future Archive | Designed for Polymaths</p>
      </footer>

      <style>{`
        .custom-scrollbar::-webkit-scrollbar { width: 3px; }
        .custom-scrollbar::-webkit-scrollbar-thumb { background: rgba(58, 110, 255, 0.4); border-radius: 20px; }
        .scrollbar-hide::-webkit-scrollbar { display: none; }
        .shadow-4xl { box-shadow: 0 80px 180px -40px rgba(0,0,0,1); }
        .hd-render { 
          image-rendering: -webkit-optimize-contrast; 
          image-rendering: high-quality;
          filter: contrast(1.02) brightness(1.01) saturate(1.05);
        }
      `}</style>
    </div>
  );
};

const ProductCard: React.FC<{ product: Product; onClick: () => void }> = ({ product, onClick }) => (
  <article className={`group cursor-pointer space-y-8 animate-in slide-up duration-700 ${product.status === 'Out of Stock' ? 'opacity-80' : ''}`} onClick={onClick}>
    <div className="aspect-[3/4] bg-zinc-950 rounded-[3rem] overflow-hidden relative shadow-3xl border border-white/5 group-hover:border-[#3A6EFF]/20 transition-all duration-700">
      <img src={product.image} className={`w-full h-full object-cover transition-all duration-1000 group-hover:scale-110 group-hover:rotate-1 hd-render ${product.status === 'Out of Stock' ? 'grayscale opacity-50' : ''}`} />
      <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-transparent opacity-40 group-hover:opacity-60 transition-opacity duration-700" />
      
      {/* HD Badge */}
      <div className="absolute top-8 left-8 flex flex-col gap-2">
         <span className={`px-4 py-1.5 rounded-xl text-[8px] font-black uppercase tracking-widest border shadow-2xl backdrop-blur-md ${product.status === 'Active' ? 'bg-green-500/20 text-green-400 border-green-500/20' : 'bg-red-500/20 text-red-400 border-red-500/20'}`}>
           {product.status}
         </span>
         <span className="bg-[#3A6EFF]/40 backdrop-blur-md text-white border border-[#3A6EFF]/20 px-4 py-1.5 rounded-xl text-[8px] font-black tracking-widest flex items-center gap-2 opacity-0 group-hover:opacity-100 transition-all duration-500">
           <Zap size={10} className="fill-current"/> ULTRA HD
         </span>
      </div>

      <div className="absolute bottom-10 left-10 right-10 flex justify-center translate-y-20 opacity-0 group-hover:translate-y-0 group-hover:opacity-100 transition-all duration-700">
        <button className="w-full bg-white text-black py-6 rounded-[2rem] text-[10px] font-black uppercase tracking-[0.4em] shadow-4xl hover:bg-[#3A6EFF] hover:text-white transition-all">Examine Artifact</button>
      </div>
    </div>
    <div className="flex justify-between items-start px-6">
      <div className="space-y-1">
        <h3 className="text-3xl font-black italic uppercase tracking-tighter truncate max-w-[220px] leading-none">{product.name}</h3>
        <p className="text-[9px] font-black text-gray-600 uppercase tracking-widest italic flex items-center gap-2">
          {product.category} <span className="text-[#3A6EFF]/40">•</span> <span className="text-[#3A6EFF]">HD-QUAL</span>
        </p>
      </div>
      <p className="text-2xl font-black italic text-white tracking-tighter">ETB {product.price.toLocaleString()}</p>
    </div>
  </article>
);

export default App;
