
/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
import { GoogleGenAI } from '@google/genai';
import { DeviceMetadata } from './fingerprintService';

export const analyzeDigitalIdentity = async (
  metadata: DeviceMetadata,
  location?: { lat: number; lng: number }
): Promise<string> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  
  const prompt = `
    Analyze this device fingerprint data and reconstruct a likely profile of the user and their situation.
    
    METADATA:
    - GPU: ${metadata.gpu}
    - Platform: ${metadata.platform}
    - Display: ${metadata.screen}
    - Battery: ${metadata.battery}
    - Network: ${metadata.connection}
    - Cores/Memory: ${metadata.cores} cores, ${metadata.memory}GB RAM
    - Timezone/Lang: ${metadata.timezone} / ${metadata.language}
    - Location: ${location ? `${location.lat}, ${location.lng}` : 'Unknown'}

    Task:
    1. Identify the specific device model (be as precise as possible based on GPU/Screen).
    2. Characterize the user's current environment (e.g., at home, traveling, work).
    3. Predict the user's technical persona (e.g., Gamer, Professional, Casual, Developer).
    4. Estimate the level of privacy risk this device currently faces.

    Tone: Cyber-detective, clinical, slightly unsettling but informative.
  `;

  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: [{ role: 'user', parts: [{ text: prompt }] }],
    config: {
      temperature: 0.7,
      topP: 0.9,
      thinkingConfig: { thinkingBudget: 0 }
    }
  });

  return response.text || "Identity synthesis failed.";
};
